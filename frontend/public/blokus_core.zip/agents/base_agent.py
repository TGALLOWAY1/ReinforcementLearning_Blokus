"""
Base agent class
"""
